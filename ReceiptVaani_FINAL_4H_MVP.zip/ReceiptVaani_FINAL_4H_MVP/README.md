# ReceiptVaani — 4-hour final MVP

## Run locally

```powershell
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```

Open the URL Streamlit prints, usually `http://localhost:8501`.

## Demo mode
Demo Mode works without an API key and is intended for the final presentation flow:
- Previous bill: ₹1,240
- Current bill: ₹1,849
- New service fee: ₹528

Label demo data as synthetic.

## Live AI mode
In the sidebar switch to **Live AI**, paste a Gemini API key, upload your current and previous bills, and click Analyze.

The app uses Gemini multimodal input + structured output for bill extraction. Google documents structured output with Pydantic and multimodal image/document input. See:
https://ai.google.dev/gemini-api/docs/structured-output

## Deploy in a hurry
Push these files to GitHub. In Streamlit Community Cloud, create an app from the repo and select `app.py` as the entrypoint. Put the Python dependencies in `requirements.txt`.

For a cloud deployment, add the API key as an app secret named:
`GEMINI_API_KEY`

Do not commit API keys to GitHub.
